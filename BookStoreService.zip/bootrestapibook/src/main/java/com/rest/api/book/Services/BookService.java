package com.rest.api.book.Services;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rest.api.book.Dao.BookRepository;
import com.rest.api.book.Entity.Book;
@Component
public class BookService {
	
	@Autowired
	private BookRepository bookRepository;
	
	
	
	//--------------------GET ALL BOOKS SERVICE LAYER-----------------------////
	public List<Book> getAllBooks(){
		List<Book> list=(List<Book>)this.bookRepository.findAll();
		return list;	
	}
	
	//---------------------GET SINGLE BOOK BY ID--------------------------////
	public Book getBookById(int id){
		Book book=null;
		try {
		book=this.bookRepository.findById(id);
		}catch(Exception e) {
			e.printStackTrace();
		
		}
		return book;
	}
	
	//----------------------ADD BOOK SERVICE LAYER----------------------////
		public Book addBook (Book b) {
			Book result=bookRepository.save(b);
			return result;
		}
		//-------------------DELETE BOOK SERVICE LAYER-----------------////
		public void deleteBook(int bid) {
			// TODO Auto-generated method stub
			bookRepository.deleteById(bid);
			
			
		}
		//UPDATE BOOKS SERVICE LAYER------------------------////
		public void updateBook(Book book, int bookid) {
			book.setId(bookid);
			bookRepository.save(book);
		}

}
